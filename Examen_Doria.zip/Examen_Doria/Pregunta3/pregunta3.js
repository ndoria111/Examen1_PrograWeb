
const validar = function(){

    const nombre = document.getElementById("input_nombre")
    const edad = document.getElementById("input_edad")
    const alerta = document.getElementById("tmensaje")
    const alerta_buena = document.getElementById("mensaje_correcto")

    if(edad.value == "" ||nombre.value == ""){
        alerta.setAttribute("class","alert alert-danger")
        alerta.innerText = "Error, debe llenar los 2 campos"
        return 
    }else{
        alerta_buena.innerText = "Se guardó con éxito"
        alerta_buena.setAttribute("class", "alert alert-success")
        return

    }
}


const main = function (){
    const but = document.getElementById("but")
    but.addEventListener("click", validar)


}

main()